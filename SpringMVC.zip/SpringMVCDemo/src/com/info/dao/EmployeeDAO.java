package com.info.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

import com.info.model.Employee;

@Repository
public class EmployeeDAO {

	Connection connection;

	public EmployeeDAO() {
		connection = DBConnection.createConnection();
	}

	public boolean checkEmployee(Employee employee) {
		boolean flag = false;
		try {
			String query = "select * from employee where username=? and password=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, employee.getUsername());
			preparedStatement.setString(2, employee.getPassword());

			ResultSet resultSet = preparedStatement.executeQuery();

			flag = resultSet.next();
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return flag;
	}
	
	public void addEmployee(Employee employee) {
		
		try {
			String query = "insert into employee(firstname, lastname, gender, salary, username, password) values(?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1, employee.getfirstname());
			preparedStatement.setString(2, employee.getlastname());
			preparedStatement.setString(3, employee.getGender());
			preparedStatement.setDouble(4, employee.getSalary());
			preparedStatement.setString(5, employee.getUsername());
			preparedStatement.setString(6, employee.getPassword());
			
			preparedStatement.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
