package com.info.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	static Connection connection;

	static {
		try {
			String driver = "com.mysql.cj.jdbc.Driver";
			Class.forName(driver);

			String url = "jdbc:mysql://localhost:3306/fullstack?useSSL=false";
			String username = "root";
			String password = "root";

			connection = DriverManager.getConnection(url, username, password);	
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static Connection createConnection()  
	{
		return connection;
	}
}
