package com.info.service;

import org.springframework.stereotype.Service;

import com.info.dao.EmployeeDAO;
import com.info.model.Employee;

@Service
public class EmployeeService {
	
	EmployeeDAO eDao;
	
	public EmployeeService() {
		eDao = new EmployeeDAO();
	}
	
	public boolean checkEmployee(Employee employee)
	{
		boolean flag = eDao.checkEmployee(employee);
		return flag;
	}
	
	public void addEmployee(Employee employee) {
		eDao.addEmployee(employee);
	}
}
