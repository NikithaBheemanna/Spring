package com.info.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.info.model.Employee;
import com.info.service.EmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	EmployeeService eService;
	
	@RequestMapping("/getLoginPage.htm")
	public ModelAndView showLoginPage() {
		
		Employee employee = new Employee();
		ModelAndView modelAndView = new ModelAndView();
	
		modelAndView.addObject("emp", employee);
		modelAndView.setViewName("Login.jsp");
		
		return modelAndView;
	}
	
	@RequestMapping("/check.htm")
	public ModelAndView checkEmployee(Employee employee) {
		
		boolean flag = eService.checkEmployee(employee);
		
		ModelAndView modelAndView = new ModelAndView();
		
		if(flag) {
			modelAndView.addObject("user", employee.getUsername());
			modelAndView.setViewName("Home.jsp");
		}
		else {
			modelAndView.addObject("message", "Invalid credentials");
			
			Employee employee2 = new Employee();
			modelAndView.addObject("emp",employee2);
			modelAndView.setViewName("Login.jsp");
		}
		return modelAndView;
	}

	@RequestMapping("/getCreatePage.htm")
	public ModelAndView showCreatePage() {
		Employee employee = new Employee();
		ModelAndView modelAndView = new ModelAndView();
		
		Map<String, String> genderMap = new HashMap<>();
		genderMap.put("Male", "Male");
		genderMap.put("Female", "Female");
		genderMap.put("Other", "Other");
		
		modelAndView.addObject("gMap", genderMap);
		modelAndView.addObject("emp", employee);
		modelAndView.setViewName("CreateEmployee.jsp");
		
		return modelAndView;
	}
	
	@RequestMapping("/create.htm")
	public ModelAndView addEmployee(Employee employee) {
		 
		 eService.addEmployee(employee);
		 
		 ModelAndView modelAndView = new ModelAndView(); 
		 modelAndView.addObject("message", employee.getfirstname() + " employee created");
		 modelAndView.setViewName("Login.jsp");
		 return modelAndView;
	}
}
