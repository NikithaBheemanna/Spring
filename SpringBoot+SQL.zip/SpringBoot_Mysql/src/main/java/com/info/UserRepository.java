package com.info;

import org.springframework.data.repository.CrudRepository;

// This will be auto implemented by Spring into a Bean called userRepository
//
public interface UserRepository extends CrudRepository<User, Integer> {

}
