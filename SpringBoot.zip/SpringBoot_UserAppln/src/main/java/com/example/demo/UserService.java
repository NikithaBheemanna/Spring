package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.User;

@RestController
public class UserService {

	private List<User> userList = new ArrayList<>();
		
	@PostConstruct
	public void loadUser() {
		
		userList.add(new User(1, "Mary Kom", "Female", "Boxer"));
		userList.add(new User(2, "Babita Phogat", "Female", "Wrestler"));
		userList.add(new User(3, "Sanya Mirza", "Female", "Tennis"));
		
		System.out.println("User Added from eclipse");
	}
	
	@PostMapping(value = "/UserService/userList", consumes = "application/json")
	public void addUser(@RequestBody User user) {
		userList.add(user);
		
		System.out.println(user.getUser_id());
		System.out.println(user.getUser_name());
		System.out.println(user.getGender());
		System.out.println(user.getOccupation());
		System.out.println(userList.size());
		
		System.out.println("User Added from webpage");
	}
	
	@GetMapping(value = "/UserService/userList{}", produces="application/json")
	public User getUserById(@PathVariable("user_id") int id) {	
		User u = null;
		int flag = 0;
		
		for(User user : userList)
		{
			if (user.getUser_id() == id) {
				flag = 1;
				u = user;
				break;
			}
		}
		return flag != 0 ? u : new User(0, "User not found", "null", "null");
	}
	
}
